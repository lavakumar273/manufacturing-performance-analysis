SELECT * FROM crowdfunding.mdcsv;
use crowdfunding;

# 1. Manufacture Qty

SELECT SUM(`Manufactured Qty`) AS total_manufactured_qty
FROM mdcsv;

# 2. Rejected Qty

SELECT SUM(`Rejected Qty`) AS total_rejected_qty
FROM mdcsv;

# 3. Processed Qty

SELECT SUM(`Processed Qty`) AS total_processed_qty
FROM mdcsv;

# 4. Wastage Qty

SELECT 
  SUM(`Rejected Qty`) AS total_rejected_qty,
  SUM(`Manufactured qty`) AS total_manufactured_qty,
  ROUND(
    (SUM(`Rejected Qty`) / SUM(`Manufactured qty`)) * 100,
    2
  ) AS wastage_percentage
FROM mdcsv;

#  5. Employee Wise Rejected Qty

SELECT `Emp Name`, SUM(`Rejected Qty`) AS total_rejected_qty
FROM mdcsv
GROUP BY `Emp Name`
ORDER BY total_rejected_qty DESC;

# 6. Machine Wise Rejected Qty

SELECT `Machine Name`, SUM(`Rejected Qty`) AS total_rejected_qty
FROM mdcsv
GROUP BY `Machine Name`
ORDER BY total_rejected_qty DESC;

# 7. Production Comparison Trend

SELECT DATE(`Doc Date`) AS date,
       SUM(`Manufactured Qty`) AS manufactured,
       SUM(`Rejected Qty`) AS rejected,
       SUM(`Processed Qty`) AS processed
FROM mdcsv
GROUP BY DATE(`Doc Date`)
ORDER BY DATE(`Doc Date`);

# 8. Manufacture Vs Rejected

SELECT 
    SUM(`Manufactured Qty`) AS total_manufactured,
    SUM(`Rejected Qty`) AS total_rejected
FROM mdcsv;

# 9. Department Wise Manufacture Vs Rejected

SELECT `Department Name`, 
       SUM(`Manufactured Qty`) AS manufactured,
       SUM(`Rejected Qty`) AS rejected
FROM mdcsv
GROUP BY `Department Name`;

# 10. Emp Wise Rejected Qty

SELECT `Emp Name`, SUM(`Rejected Qty`) AS total_rejected_qty
FROM mdcsv
GROUP BY `Emp Name`
ORDER BY total_rejected_qty DESC;






